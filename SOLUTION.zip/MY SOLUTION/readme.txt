if you dont know anything about ML, check my ML with statistic,calculus and data science tutorial videos here (Turkish) >>> https://www.youtube.com/watch?v=qvWGlnHatDo&list=PLNgNWpM7HbsDuDQhrucGQeXtlctwep6ZW&pp=gAQBiAQB
also if you know ML and solved your problem, support me (like,sub) >>> https://www.youtube.com/@HasanCanBeydili


***** TUTORIAL USAGE OF MY SOLUTION AND LEARN DYNAMICS FOR THIS PROGRAM (Turkish) >>> https://www.youtube.com/watch?v=QzsyHsOJf30&list=PLNgNWpM7HbsDuDQhrucGQeXtlctwep6ZW&index=12&pp=gAQBiAQB